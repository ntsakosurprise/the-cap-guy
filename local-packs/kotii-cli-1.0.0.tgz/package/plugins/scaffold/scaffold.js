const methods = require("./methods");

const execa = require("execa");
const Listr = require("listr");
const simpleGit = require("simple-git");
const pkgInstall = require("pkg-install");
const path = require("path");
const chalk = require("chalk");

const Configstore = require("configstore");
const Octokit = require("@octokit/rest");
const { createBasicAuth } = require("@octokit/auth-basic");
const github = require("octonode");
const { projectInstall } = require("pkg-install");
const isOnline = require("is-online");

// const Bitbucket = require('bitbucket').Bitbucket
// const pkg = require('../package.json')
// const conf = new Configstore(pkg.name);

/**
 * The methods container file for Scaffold plugin. Methods files in anzii
 * ecosystem's plugins are usually created to prevent clutter in the plugin's
 * class file
 * @class Scaffold
 * @constructor 
 
 */

class Scaffold {
  constructor(pao) {
    this.pao = pao;
    this.Listr = Listr;
    this.execa = execa;
    this.chalk = chalk;
    this.Octokit = Octokit;
    this.simpleGit = simpleGit;
    this.Configstore = Configstore;
    this.github = github;
    this.projectInstall = projectInstall;
    this.isOnline = isOnline;
    this.isLocalRun = false;
    this.path = path;
    this.packagersInstallMap = {
      npm: "i",
      yarn: "add",
    };
    this.defaultAnswers = {
      type: "ssr",
      template: "javascript",
      packager: "npm",
      description: "A hello world application",
      git: "yes",
      repotype: "public",
    };
    //  this.Bitbucket = Bitbucket
    //  this.octokit = new Octokit()
    this.createBasicAuth = createBasicAuth;
    this.questions = {
      remote: [
        {
          name: "provider",
          type: "list",
          key: "provider",
          message: "Which remote provider do you use?",
          choices: ["Github"],
        },
        {
          name: "username",
          type: "input",
          key: "username",
          message: "Enter your GitHub username or e-mail address:",
          validate: function (value) {
            if (value.length) {
              return true;
            } else {
              return "Please enter your username or e-mail address.";
            }
          },
        },
        {
          name: "password",
          type: "password",
          key: "password",
          message: "Enter password:",
          validate: function (value) {
            if (value.length) {
              return true;
            } else {
              return "Please enter your password:";
            }
          },
        },
      ],
      account: [
        {
          name: "account",
          type: "list",
          key: "account",
          message: "Which account are you creating this repo for?",
          choices: [],
        },
      ],
      getTwoFactor: [
        {
          name: "twoFactorAuthenticationCode",
          type: "input",
          message: "Enter your two-factor authentication code:",
          validate: function (value) {
            if (value.length) {
              return true;
            } else {
              return "Please enter your two-factor authentication code.";
            }
          },
        },
      ],
      general: [
        {
          name: "apptype",
          type: "list",
          key: "apptype",
          message: "What type of app would you like to create?",
          choices: [
            "spa(single page application)",
            "ssr(server side rendered application)",
            "mua(multipage application)",
          ],
        },
        {
          name: "template",
          type: "list",
          message: "Which template do you want to use?",
          key: "template",
          choices: ["javascript", "typescript"],
        },
        // {
        //   name: "init",
        //   type: "list",
        //   message: "Should we initialize the project for you?",
        //   key: "init",
        //   choices: ["Yes", "No"],
        // },
        {
          name: "packager",
          type: "list",
          key: "packager",
          message: "Which packager do you prefer?",
          choices: ["yarn", "npm", "pnp"],
        },
        {
          name: "description",
          type: "input",
          key: "description",
          message: "Please provide an optional project description:",
          validate: function (value) {
            if (value.length) {
              return true;
            } else {
              // return 'Please enter your password.';
              return false;
            }
          },
        },
        {
          name: "git",
          type: "list",
          message: "Should we initialize git for you?",
          key: "git",
          choices: ["Yes", "No"],
        },

        {
          name: "repotype",
          type: "list",
          key: "repotype",
          message: "Should this be a public or private repo?",
          choices: ["Public", "Private"],
        },
        // {
        //   name: "remote",
        //   type: "list",
        //   message: "Should we create a remote repository for you?",
        //   key: "remote",
        //   choices: ["Yes", "No"],
        // },
      ],
    };

    this.init = methods.init;
    this.handleScaffoldApp = methods.handleScaffoldApp;
    this.handleScaffoldCommands = methods.handleScaffoldCommands;
    this.startQuestionnaire = methods.startQuestionnaire;
    this.getInterpreterFeed = methods.getInterpreterFeed;
    this.createRemoteRepo = methods.createRemoteRepo;
    this.authenticateUser = methods.authenticateUser;
    this.getStoredUserToken = methods.getStoredUserToken;
    this.getRemoteUserToken = methods.getRemoteUserToken;
    this.storeUserConfigs = methods.storeUserConfigs;
    this.makeFolder = methods.makeFolder;
    this.gitInit = methods.gitInit;
    this.packagesInstall = methods.packagesInstall;
    this.runTasks = methods.runTasks;
    this.getMoData = methods.getMoData;
    this.getStoredUserTokenFeedback = methods.getStoredUserTokenFeedback;
    this.getRemoteUserTokenFeedback = methods.getRemoteUserTokenFeedback;
    this.createProjectBase = methods.createProjectBase;
    this.buildTaskList = methods.buildTaskList;
    this.startProjectCreation = methods.startProjectCreation;
    this.isExistingDir = methods.isExistingDir;
    this.isInternetConnected = methods.isInternetConnected;
    this.startPostAuthenticationTasks = methods.startPostAuthenticationTasks;
    this.mergeQuestions = methods.mergeQuestions;
    this.deleteMatchedQuestion = methods.deleteMatchedQuestion;
    this.doPackageJson = methods.doPackageJson;
    this.installLocally = methods.installLocally;
    this.runTerminal = methods.runTerminal;
    this.renderTerminalError = methods.renderTerminalError;
    this.cancellProjectCreation = methods.cancellProjectCreation;
    this.renderError = methods.renderError;
    this.installationError = methods.installationError;
    this.createFolderError = methods.createFolderError;
    this.capitalizeFirstLetter = methods.capitalizeFirstLetter;
    this.camelCaseText = methods.camelCaseText;
    this.unknownError = methods.unknownError;
    this.npmInstallationConfig = methods.npmInstallationConfig;
    this.yarnInstallationConfig = methods.yarnInstallationConfig;
    this.pnpmInstallationConfig = methods.pnpmInstallationConfig;
    this.copyFiles = methods.copyFiles;
  }
}

module.exports = Scaffold;
