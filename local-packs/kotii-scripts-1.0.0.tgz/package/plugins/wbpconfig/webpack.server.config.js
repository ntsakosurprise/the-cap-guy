import fs from "fs";
import { loggas, logger } from "kotii-logger";
import path from "path";
import { fileURLToPath } from "url";
import webpack from "webpack";
import { kotiiKotiiLandPath, kotiiRootPath } from "../../kotii_paths.js";
import {
  DeleteFilesWebpackPlugin,
  FinishCompilationOnErrorWebpackPlugin,
  HookToLoaderResolutionWebpackPlugin,
  RemoveImportsWebpackPlugin,
  StatsPrintWebpackPlugin,
  WatchOwnFilesWebpackPlugin,
} from "../../webpack-plugins/index.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
logger.setNameSpaces([
  { namespace: "webpack:compilation", id: "webpack" },
  {
    namespace: "webpack:compilation:deleteFilesWebpackPlugin",
    id: "deleteFilesWebpackPlugin",
  },
  {
    namespace: "webpack:compilation:finishCompilationOnErrorWebpackPlugin",
    id: "finishCompilationOnErrorWebpackPlugin",
  },
  {
    namespace: "webpack:compilation:hookToLoaderResolutionWebpackPlugin",
    id: "hookToLoaderResolutionWebpackPlugin",
  },
  {
    namespace: "webpack:compilation:watchOwnFilesWebpackPlugin",
    id: "watchOwnFilesWebpackPlugin",
  },
  {
    namespace: "webpack:compilation:removeImportsWebpackPlugin",
    id: "removeImportsWebpackPlugin",
  },
  {
    namespace: "webpack:compilation:statsPrintWebpackPlugin",
    id: "statsPrintWebpackPlugin",
  },
]);

export default (options) => {
  //   loggas.webpack.debug("THE PROCESS", process.env.APPCONTEXT);
  loggas.webpack.debug("THE STUFF THAT IS", options);
  let env = JSON.parse(process.env.APPCONTEXT); // GET the set APPCONTEXT environment variable
  let appEnvironmentVariables = JSON.parse(process.env.APP_ENVS); // Get context app kotii environment variables
  loggas.webpack.debug("THE APP BUILD FOLDER", env.appBuildFolder);
  loggas.webpack.debug("WEBPACK APP ENVS", appEnvironmentVariables);
  loggas.webpack.debug("THE SERVER CONFIG");
  loggas.webpack.debug("THE APP BUILD FOLDER", env.appBuildFolder);
  loggas.webpack.debug("PNPM STATUS", options.isProjectPNPM);
  loggas.webpack.debug(
    "THE DIR_NAME",
    __dirname,
    path.resolve(__dirname, "../..")
  );
  let scriptsPath = path.resolve(__dirname, "../..");
  let scriptsWebpackResolve = path.resolve(
    scriptsPath,
    "kotii-land/dev/app_.js"
  );
  loggas.webpack.debug(
    "WEBPACK KOTII RESOLVE",
    scriptsPath,
    scriptsWebpackResolve,
    fs.existsSync(scriptsWebpackResolve)
  );
  loggas.webpack.debug(
    "WEBPACK KOTII RESOLVE path.join",
    path.resolve(`${scriptsWebpackResolve}`)
  );
  const { isProjectPNPM = false } = options;

  return {
    // entry:{
    //   server: options?.build && options.build
    //   ? env.appIndexFile
    //   : ["webpack-hot-middleware/client?path=/__kotii", env.appIndexFile],
    //   "kotii-client": `${scriptsPath}/client-tools/index.js`
    // },
    entry:
      options?.build && options.build
        ? env.appIndexFile
        : ["webpack-hot-middleware/client?path=/__kotii", env.appIndexFile],

    context: env.appFolder,
    mode: process.env.NODE_ENV,
    infrastructureLogging: { level: "none" },
    stats: "errors-only",
    output: {
      filename: "server.bundle.js",
      path:
        options?.build && options.build
          ? options.staticFolder
          : `${env.appBuildFolder}`, // save emitted bundle to this path or folder
      clean: true, // Clean build folder before emitting new bundle
      publicPath: "/",
      assetModuleFilename: (pathData, assetInfo) => {
        loggas.webpack.debug("THE PATH DATA", pathData.filename);
        //loggas.webpack.debug("THE PATH INFO", assetInfo);
        return `${path.basename(pathData.filename)}`;
      },
    },
    //externals: {
    // react: {
    //   root: "React",
    //   commonjs2: "react",
    //   commonjs: "react",
    //   amd: "react",
    //   umd: "react",
    // },
    //   React: "react",
    // },

    // externals: [
    //   webpackNodeExternals({
    //     allowlist: ["kotii-scripts"],
    //   }),
    // ],
    resolve: {
      extensions: [".js", ".jsx", ".png", ".jpg"], // tell webpack to use these extenstions to resolve imported files[for importing without specifying the extension name]
      alias: {
        ...options.appManifest.aliases,
        "react-router-dom": path.resolve(
          `${env.appFolder}/node_modules/react-router-dom`
        ),
        react: path.resolve(`${env.appFolder}/node_modules/react`),
        "react-router": path.resolve(
          `${env.appFolder}/node_modules/react-router`
        ),
        "kotii-scripts": path.resolve(`${scriptsWebpackResolve}`),
      }, // Alias references to files and folders inorder to use absolute paths in your file imports
      fallback: {
        fs: false,
        path: false,
        url: false,
        tls: false,
        net: false,
        zlib: false,
        http: false,
        https: false,
        stream: false,

        // "crypto": false,
      }, // Add these as polyfills for use in the browser, webpack no longer auto-polyfills them
      modules: !isProjectPNPM
        ? ["node_modules"]
        : [
            process.cwd(),
            path.join(process.cwd(), "node_modules"),
            path.join(process.cwd(), "node_modules/.pnpm/node_modules"),
          ],
    },
    resolveLoader: {
      alias: {
        "syncAssets-loader": path.resolve(
          `${kotiiRootPath}`,
          "webpack-loaders/syncAssetsLoader.cjs"
        ),
        "sync-styles-loader": path.resolve(
          `${kotiiRootPath}`,
          "webpack-loaders/syncStylesLoader.cjs"
        ),
        "handle-sync-styles-loader": path.resolve(
          `${kotiiRootPath}`,
          "webpack-loaders/handleSyncLoaderStyles.cjs"
        ),
        // "test-styles-loader": path.resolve(
        //   `${kotiiRootPath}`,
        //   "webpack-loaders/testStyles.cjs"
        // ),
      },
    },
    module: {
      rules: [
        {
          test: /\.(?:js|mjs|cjs|jsx)$/,
          include: !isProjectPNPM
            ? [path.resolve(scriptsPath, "/")]
            : [
                process.cwd(),
                path.join(process.cwd(), "node_modules"),
                path.join(process.cwd(), "node_modules/.pnpm/node_modules"),
              ],
          // exclude: /node_modules\/(?!(kotii-scripts)\/).*/,
          // include: [scriptsWebpackResolve],
          exclude: !isProjectPNPM
            ? /node_modules\/(?!kotii-scripts).+/
            : /node_modules\/\.pnpm\/node_modules\/(?!kotii-scripts)/,
          use: {
            loader: "babel-loader",
            options: {
              presets: [
                ["@babel/preset-env"],
                ["@babel/preset-react", { runtime: "automatic" }],
              ],
            },
          },
        },
        {
          test: /\.html$/,
          use: "html-loader",
        },
        {
          test: /\.(css|sass|scss|less|styl)$/i,
          use: [
            {
              loader: "handle-sync-styles-loader",
              options: {
                referenceAssetsPath: `${kotiiKotiiLandPath}/dev`,
                assetsFile: "styles-css-modules.json",
                fileFormat: "json",
              },
            },
            {
              loader: "sync-styles-loader",
              options: {
                referenceAssetsPath: `${kotiiKotiiLandPath}/dev`,
                assetsFile: "styles-css-modules.json",
                fileFormat: "json",
              },
            },
          ],
        },
        {
          test: /\.(csv|tsv)$/i,
          use: ["csv-loader"],
        },
        {
          test: /\.xml$/i,
          use: ["xml-loader"],
        },

        {
          test: /\.(svg|jpg|jpeg|gif)$/i,
          loader: "file-loader",
          options: getFileLoaderOptions(),
        },
        {
          test: /\.png$/i,
          use: [
            {
              loader: options.useInlinedPngs
                ? "syncAssets-loader"
                : "file-loader",
              options: options.useInlinedPngs
                ? {
                    referenceAssetsPath: kotiiKotiiLandPath,
                    assetsFile: "assets.manifest.json",
                    fileFormat: "json",
                  }
                : getFileLoaderOptions(),
            },
          ],
        },
        {
          test: /\.m?js?x$/,
          resolve: {
            fullySpecified: false, // disable the behaviour
          },
        },
        /*Choose only one of the following two: if you're using
                  plain CSS, use the first one, and if you're using a
                  preprocessor, in this case SASS, use the second one*/
        // {
        //   test: /\.css$/,
        //   use: ["style-loader", "css-loader"],
        // },
        // {
        //   test: /\.less$/i,
        //   use: [
        //     // compiles Less to CSS
        //     "style-loader",
        //     "css-loader",
        //     "less-loader",
        //   ],
        // },
        // {
        //   test: /\.s[ac]ss$/i,
        //   use: [
        //     // Creates `style` nodes from JS strings
        //     "style-loader",
        //     // Translates CSS into CommonJS
        //     "css-loader",
        //     // Compiles Sass to CSS
        //     "sass-loader",
        //   ],
        // },
        // {
        //   test: /\.styl$/,
        //   use: [
        //     "style-loader",
        //     "css-loader",
        //     {
        //       loader: "stylus-loader",
        //       options: {
        //         webpackImporter: false,
        //       },
        //     },
        //   ],
        // },

        // {
        //   test: /\.scss$/,
        //   use: ["style-loader", "css-loader", "sass-loader"],
        // },
      ],
    },

    // devServer: {
    //   allowedHosts: "auto",
    //   client: {
    //     overlay: { warnings: false, errors: false, runtimeErrors: false },
    //   },
    //   port: 9000,
    //   devMiddleware: {
    //     writeToDisk: true /*serve in-memory[devserver] as you did before but save to disk as well (changes to file[s] respected) */,
    //   },
    //   static: {
    //     directory: env.appAssetsPublic, // config devserv to server public assets from here
    //   },
    // },
    plugins: [
      // new HTMLWebpackPlugin({
      //   // template: env.appIndexHtml,
      //   filename: "index.html",
      // }),
      new DeleteFilesWebpackPlugin(
        {
          deleteFolder: options.buildFolder,
        },
        loggas
      ),
      new HookToLoaderResolutionWebpackPlugin(loggas),

      new FinishCompilationOnErrorWebpackPlugin(
        {
          closeWatcher: options.closeWatcher,
        },
        loggas
      ),
      new WatchOwnFilesWebpackPlugin(
        {
          filesToWatch: `${options.pagesFolder}`,
          runOnComplete: options.runOnComplete,
          notifyClient: options.notifyClient,
        },
        loggas
      ),
      // new GetStatsWebpackPlugin({ writeFilePath: env.appBuildFolder }),
      new webpack.DefinePlugin({
        "process.env": {
          ...appEnvironmentVariables,
        },
      }),
      new webpack.HotModuleReplacementPlugin(),
      new RemoveImportsWebpackPlugin(
        {
          removeFilePath: `${scriptsPath}/kotii-land/dev/build.js`,
          removeFileSpecifiers: ["./pages.js"],
        },
        loggas
      ),
      new StatsPrintWebpackPlugin(loggas),
    ],
  };
};

const getFileLoaderOptions = () => {
  return {
    name: "[name].[ext]",
  };
};
