import chalk from "chalk";
import { exec } from "child_process";
export default function ({
  npmCommand = "run",
  scriptToRun = "build-ssr",
  options = "",
  cwd = process.cwd(),
} = args) {
  return new Promise((resolve, reject) => {
    let terminalOptions =
      options instanceof Array ? options.join(" ") : options.trim();
    let commandToRun = `npm ${npmCommand} ${scriptToRun} ${terminalOptions}`;
    console.log("command to run", commandToRun);
    exec(`${commandToRun}`, { cwd: cwd }, (err, stdout) => {
      console.log("THE SCOPED STDOUT", stdout);
      if (err)
        console.log(chalk.redBright.bold("Npm script failed with error:"), err);
      if (err) reject(false);
      console.log(chalk.bgGreen.bold("Npm script ran successfully"));
      resolve(true);
    });
  });
}
